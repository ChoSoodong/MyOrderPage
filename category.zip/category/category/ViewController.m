//
//  ViewController.m
//  category
//
//  Created by xialan on 2019/3/21.
//  Copyright © 2019 category. All rights reserved.
//

#import "ViewController.h"
#import "SDTestController.h"

#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]

@interface ViewController ()<ZJScrollPageViewDelegate>

@property(strong, nonatomic)NSArray<NSString *> *titles;
@property(strong, nonatomic)NSArray<UIViewController *> *childVcs;
@property (nonatomic, strong) ZJScrollPageView *scrollPageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"我的订单";
    
    //必要的设置, 如果没有设置可能导致内容显示不正常
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    ZJSegmentStyle *style = [[ZJSegmentStyle alloc] init];
    //显示滚动条
    style.showLine = YES;
    // 颜色渐变
    style.gradualChangeTitleColor = YES;
    //标题是否可以滚动
    style.scrollTitle = NO;
    //内容view是否有弹性效果
    style.contentViewBounces = NO;
    /** 点击标题切换的时候,内容view是否会有动画 */
    style.animatedContentViewWhenTitleClicked = NO;
    //标题选中的颜色
    style.selectedTitleColor = [UIColor redColor];
    //标题一般状态的颜色
    style.normalTitleColor = RGBA(51, 51, 51, 1);
    //滚动条颜色
    style.scrollLineColor = [UIColor redColor];
    //滚动条自适应宽度
    style.adjustCoverOrLineWidth = YES;
    
    self.titles = @[@"全部订单",
                    @"待付款",
                    @"待发货",
                    @"待收货",
                    @"待评价"
                    ];
    // 初始化
    _scrollPageView = [[ZJScrollPageView alloc] initWithFrame:CGRectMake(0, 64.0, self.view.bounds.size.width, self.view.bounds.size.height - 64.0) segmentStyle:style titles:self.titles parentViewController:self delegate:self];
    
    [self.view addSubview:_scrollPageView];
    
    
}
- (NSInteger)numberOfChildViewControllers {
    return self.titles.count;
}

- (UIViewController<ZJScrollPageViewChildVcDelegate> *)childViewController:(UIViewController<ZJScrollPageViewChildVcDelegate> *)reuseViewController forIndex:(NSInteger)index {
    UIViewController<ZJScrollPageViewChildVcDelegate> *childVc = reuseViewController;
    
//    if (!childVc) {
//        childVc = [[SDTestController alloc] init];
//    }
    
    if (index == 0) {
        childVc = [[SDTestController alloc] init];
    }else if(index == 1){
        childVc = [[SDTestController alloc] init];
    }else if(index == 2){
        childVc = [[SDTestController alloc] init];
    }else if(index == 3){
        childVc = [[SDTestController alloc] init];
    }else{
        childVc = [[SDTestController alloc] init];
    }
    
    
    //    NSLog(@"%ld-----%@",(long)index, childVc);
    
    return childVc;
}


- (BOOL)shouldAutomaticallyForwardAppearanceMethods {
    return NO;
}


@end
