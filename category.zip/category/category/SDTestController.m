//
//  SDTestController.m
//  category
//
//  Created by xialan on 2019/4/24.
//  Copyright © 2019 category. All rights reserved.
//

#import "SDTestController.h"
@interface SDTestController()<UITableViewDelegate,UITableViewDataSource>

/** tableView */
@property (nonatomic, strong) UITableView *tableView;

@end

@implementation SDTestController

-(void)viewDidLoad{
    [super viewDidLoad];
    
    self.view.backgroundColor =  [UIColor whiteColor];
    
    [self.view addSubview:self.tableView];
}


- (void)dealloc
{
    NSLog(@"-销毁-");
}

- (void)zj_viewWillAppearForIndex:(NSInteger)index{
    NSLog(@"%zd",index);
}
- (void)zj_viewDidAppearForIndex:(NSInteger)index{
    
}
- (void)zj_viewWillDisappearForIndex:(NSInteger)index{
    
}
- (void)zj_viewDidDisappearForIndex:(NSInteger)index{
    
}


#pragma mark - 数据源方法
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    
    return 20;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    

        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
        
        // 设置 Cell...
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor =  [UIColor colorWithRed:((float)arc4random_uniform(256) / 255.0) green:((float)arc4random_uniform(256) / 255.0) blue:((float)arc4random_uniform(256) / 255.0) alpha:1.0];;
    
    cell.textLabel.text = @"";
    
        return cell;
        

    
    
}

#pragma mark - 创建TableView
-(UITableView *)tableView{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        
        _tableView.backgroundColor = [UIColor clearColor];
        
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        _tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
        _tableView.scrollIndicatorInsets = _tableView.contentInset;
        
        
        _tableView.rowHeight = 80;
        
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;

        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cellid"];
        
        
        
        _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self->_tableView.mj_header endRefreshing];
            });
        }];
        
    }
    return _tableView;
}



@end
