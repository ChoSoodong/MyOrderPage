//
//  AppDelegate.h
//  category
//
//  Created by xialan on 2019/3/21.
//  Copyright © 2019 category. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

