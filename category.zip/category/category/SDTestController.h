//
//  SDTestController.h
//  category
//
//  Created by xialan on 2019/4/24.
//  Copyright © 2019 category. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZJScrollPageViewDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface SDTestController : UIViewController <ZJScrollPageViewChildVcDelegate>

@end

NS_ASSUME_NONNULL_END
