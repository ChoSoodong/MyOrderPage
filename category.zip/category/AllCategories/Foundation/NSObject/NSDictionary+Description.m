






#import "NSDictionary+Description.h"

@implementation NSDictionary (Description)

- (NSString *)descriptionWithLocale:(id)locale indent:(NSUInteger)level
{
    NSMutableString *str = [NSMutableString stringWithString:@"{\n"];
    [self enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        [str appendFormat:@"\t%@ = %@;\n", key, obj];
    }];
    [str appendString:@"}"];
    return str;
}


@end
